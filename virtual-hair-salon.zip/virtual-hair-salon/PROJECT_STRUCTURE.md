# Virtual Hair Salon — Arquitetura do Projeto

Stack: **Next.js 14 (App Router) + TypeScript + Tailwind CSS + React Three Fiber (Three.js) + Zustand**

## Direção de design (resumo)

- **Conceito:** um "espelho de camarim" — o viewport 3D vive dentro de uma moldura oval estilo espelho de salão, com "lâmpadas" ambiente ao redor. É o elemento de assinatura da interface.
- **Paleta:** `#0B0A0C` (fundo), `#151317` (superfície), `#F2EFEA` (texto), `#C9A15E` (latão/dourado — accent principal), `#8B5E4A` (cobre/terracota escuro — accent secundário), `#3A5A50` (verde salão, usado só em confirmações).
- **Tipografia:** *Fraunces* (display, editorial/beleza) + *Inter* (UI/corpo) + *IBM Plex Mono* (códigos de cor, specs técnicas para o cabeleireiro).
- **Motion:** o espelho "acende" (lâmpadas fade-in) ao carregar; o modelo 3D gira suavemente em idle; transições de cor/textura são crossfades, não corte seco.

## Estrutura de pastas

```
virtual-hair-salon/
├── app/
│   ├── layout.tsx                 # Fonts, metadata, dark mode base
│   ├── page.tsx                   # Página principal (orquestra o layout)
│   └── globals.css                # Tailwind + tokens de design (CSS vars)
│
├── components/
│   ├── salon/
│   │   ├── MirrorViewport.tsx     # Moldura "espelho de camarim" + <Canvas> R3F
│   │   ├── Scene3D.tsx            # Cena Three.js: luzes, câmera, controles, modelo
│   │   ├── HeadModel.tsx          # Mesh da cabeça (placeholder geométrico + textura da foto)
│   │   ├── HairModel.tsx          # Mesh do penteado, materiais por cor/textura
│   │   └── BeardModel.tsx         # Mesh de barba (opcional, masculino)
│   │
│   ├── upload/
│   │   ├── DualPhotoUpload.tsx    # Upload frente + perfil, preview, validação
│   │   └── PhotoGuideOverlay.tsx  # Guia de enquadramento (oval-guia sobre a câmera)
│   │
│   ├── panels/
│   │   ├── FaceShapeAnalysis.tsx  # Resultado da IA: formato + recomendações
│   │   ├── StyleCatalog.tsx       # Grid filtrável de penteados
│   │   ├── FilterBar.tsx          # Filtros: comprimento, estilo, gênero
│   │   ├── ColorTexturePanel.tsx  # Paleta de cor + textura + volume (sliders)
│   │   ├── BeforeAfterSlider.tsx  # Comparação lado a lado / slider
│   │   └── ExportCard.tsx         # Geração do "cartão para o cabeleireiro" (PDF/PNG)
│   │
│   └── ui/                        # primitives (Button, Slider, Tabs, Badge...)
│       ├── Button.tsx
│       ├── Slider.tsx
│       ├── Tabs.tsx
│       └── Badge.tsx
│
├── lib/
│   ├── mockData.ts                # Catálogo fictício de penteados/cores/barbas
│   ├── faceShapeAnalysis.ts       # Mock da "IA" de análise facial (heurística)
│   ├── store.ts                   # Zustand: estado global (fotos, seleção, cor, textura)
│   └── exportReport.ts            # Geração do relatório (canvas -> PNG / PDF)
│
├── public/
│   └── models/                    # .glb placeholders (cabeça base, penteados)
│
├── types/
│   └── index.ts                   # Hairstyle, ColorOption, FaceShape, etc.
│
├── package.json
├── tailwind.config.ts
└── tsconfig.json
```

## Fluxo de dados (alto nível)

1. `DualPhotoUpload` → grava as duas fotos (base64/blob URL) no `store.ts`.
2. `faceShapeAnalysis.ts` roda sobre a foto de frente (mock heurístico — pontos de referência simulados) → grava `faceShape` no store.
3. `StyleCatalog` filtra `mockData.ts` por `faceShape` + filtros do utilizador.
4. Penteado selecionado → `Scene3D` troca o `HairModel` (grupo Three.js) sobre o `HeadModel`.
5. `ColorTexturePanel` altera `material.color` / `material.roughness` / morph targets de volume em tempo real (sem reload da cena).
6. `ExportCard` faz snapshot do `<canvas>` (via `gl.domElement.toDataURL`) + dados selecionados → monta o relatório.

## Dependências principais

```json
{
  "next": "^14.2.0",
  "react": "^18.3.0",
  "three": "^0.165.0",
  "@react-three/fiber": "^8.16.0",
  "@react-three/drei": "^9.108.0",
  "zustand": "^4.5.0",
  "tailwindcss": "^3.4.0",
  "jspdf": "^2.5.1",
  "html-to-image": "^1.11.11"
}
```
