import jsPDF from "jspdf";
import { Hairstyle, ColorOption, BeardStyle } from "@/types";

interface ReportInput {
  frontPhoto: string;
  canvasSnapshot: string; // dataURL do <canvas> R3F (gl.domElement.toDataURL())
  hairstyle: Hairstyle;
  color: ColorOption;
  beard: BeardStyle | null;
}

/**
 * Monta o "cartão para o cabeleireiro" em PDF: foto original, screenshot
 * do modelo 3D escolhido, e as especificações técnicas (nome do corte,
 * código de cor) em texto legível para um profissional.
 */
export function generateHairdresserReport({
  frontPhoto,
  canvasSnapshot,
  hairstyle,
  color,
  beard,
}: ReportInput) {
  const doc = new jsPDF({ unit: "mm", format: "a5" });

  doc.setFillColor(11, 10, 12);
  doc.rect(0, 0, 148, 210, "F");

  doc.setTextColor(242, 239, 234);
  doc.setFont("helvetica", "bold");
  doc.setFontSize(16);
  doc.text("Virtual Hair Salon — Ficha do corte", 10, 15);

  doc.addImage(frontPhoto, "JPEG", 10, 22, 60, 60, undefined, "FAST");
  doc.addImage(canvasSnapshot, "PNG", 78, 22, 60, 60, undefined, "FAST");

  doc.setFontSize(10);
  doc.setFont("helvetica", "normal");
  let y = 92;
  const line = (label: string, value: string) => {
    doc.text(`${label}:`, 10, y);
    doc.text(value, 45, y);
    y += 7;
  };

  line("Corte", hairstyle.technicalName);
  line("Comprimento", hairstyle.length);
  line("Cor", `${color.name} (${color.hex})`);
  if (beard) line("Barba", beard.technicalName);

  doc.save(`ficha-corte-${hairstyle.id}.pdf`);
}
