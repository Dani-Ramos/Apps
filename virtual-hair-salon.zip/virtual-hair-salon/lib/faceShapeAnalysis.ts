import { FaceShape } from "@/types";

/**
 * MOCK de análise de formato de rosto.
 *
 * Em produção isto seria substituído por um modelo de landmarks faciais
 * (ex.: MediaPipe FaceMesh / TensorFlow.js) que mede proporções reais:
 * largura da testa, largura da maçã do rosto, largura da mandíbula e
 * comprimento do rosto, a partir da foto de frente.
 *
 * Aqui simulamos esse resultado para permitir testar toda a UI e o
 * pipeline de recomendação sem depender do modelo de visão computacional.
 */

export interface FaceShapeResult {
  shape: FaceShape;
  confidence: number; // 0 - 1
  measurements: {
    foreheadWidth: number;
    cheekboneWidth: number;
    jawWidth: number;
    faceLength: number;
  };
}

const MOCK_SHAPES: FaceShape[] = ["oval", "quadrado", "redondo", "diamante", "coracao", "alongado"];

/**
 * Recebe a foto de frente (data URL) e devolve um resultado de análise.
 * Por ora, deriva um resultado pseudo-determinístico a partir do tamanho
 * da string da imagem, para que a mesma foto sempre produza o mesmo
 * resultado durante os testes — sem chamar nenhum serviço externo.
 */
export async function analyzeFaceShape(frontPhotoDataUrl: string): Promise<FaceShapeResult> {
  // Simula latência de processamento (ex.: chamada a um modelo on-device ou API)
  await new Promise((resolve) => setTimeout(resolve, 900));

  let hash = 0;
  for (let i = 0; i < frontPhotoDataUrl.length; i += 37) {
    hash = (hash * 31 + frontPhotoDataUrl.charCodeAt(i)) % 997;
  }

  const shape = MOCK_SHAPES[hash % MOCK_SHAPES.length];
  const confidence = 0.78 + (hash % 20) / 100;

  return {
    shape,
    confidence: Math.min(confidence, 0.97),
    measurements: {
      foreheadWidth: 130 + (hash % 15),
      cheekboneWidth: 138 + (hash % 12),
      jawWidth: 120 + (hash % 18),
      faceLength: 190 + (hash % 20),
    },
  };
}

export const FACE_SHAPE_LABELS: Record<FaceShape, string> = {
  oval: "Oval",
  quadrado: "Quadrado",
  redondo: "Redondo",
  diamante: "Diamante",
  coracao: "Coração",
  alongado: "Alongado",
};

export const FACE_SHAPE_ADVICE: Record<FaceShape, string> = {
  oval: "Rosto equilibrado — a maioria dos comprimentos e franjas funciona bem.",
  quadrado: "Cortes com camadas suaves e ondulações amaciam o ângulo da mandíbula.",
  redondo: "Comprimentos com volume no topo e camadas alongam visualmente o rosto.",
  diamante: "Franjas laterais e volume na altura da mandíbula equilibram as maçãs do rosto.",
  coracao: "Cortes que trazem volume perto do queixo equilibram uma testa mais larga.",
  alongado: "Franjas e cortes na altura dos ombros reduzem o comprimento aparente do rosto.",
};
