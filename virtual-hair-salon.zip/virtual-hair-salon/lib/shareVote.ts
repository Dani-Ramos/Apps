import { ColorOption, Hairstyle } from "@/types";

export interface VoteShareState {
  hairstyleId: string;
  hairstyleName: string;
  colorHex: string;
  colorName: string;
}

/**
 * MOCK de "Opinião dos Amigos".
 *
 * Codifica a escolha atual (penteado + cor) num parâmetro de URL em
 * base64, para gerar um link partilhável sem precisar de backend.
 * Quem abre o link (`/vote?s=...`) veria uma página read-only com botões
 * de "gostei" / "não gostei" — a contagem real de votos exigiria uma API
 * simples (ex.: rota `/api/vote` gravando num KV/Postgres) que ainda não
 * está implementada neste protótipo; aqui simulamos a contagem em
 * localStorage só para a demonstração funcionar de ponta a ponta no
 * dispositivo de quem está a testar.
 */
export function buildVoteLink(hairstyle: Hairstyle, color: ColorOption): string {
  const state: VoteShareState = {
    hairstyleId: hairstyle.id,
    hairstyleName: hairstyle.name,
    colorHex: color.hex,
    colorName: color.name,
  };
  const encoded = typeof window !== "undefined" ? btoa(encodeURIComponent(JSON.stringify(state))) : "";
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/vote?s=${encoded}`;
}

export function decodeVoteLink(param: string): VoteShareState | null {
  try {
    return JSON.parse(decodeURIComponent(atob(param)));
  } catch {
    return null;
  }
}

const VOTES_KEY_PREFIX = "vhs-votes:";

export function getMockVotes(hairstyleId: string): { yes: number; no: number } {
  if (typeof window === "undefined") return { yes: 0, no: 0 };
  const raw = window.localStorage.getItem(VOTES_KEY_PREFIX + hairstyleId);
  return raw ? JSON.parse(raw) : { yes: 0, no: 0 };
}

export function castMockVote(hairstyleId: string, vote: "yes" | "no") {
  if (typeof window === "undefined") return;
  const current = getMockVotes(hairstyleId);
  current[vote] += 1;
  window.localStorage.setItem(VOTES_KEY_PREFIX + hairstyleId, JSON.stringify(current));
}
