import { create } from "zustand";
import {
  UserPhotos,
  Hairstyle,
  ColorOption,
  HairTexture,
  BeardStyle,
  FaceShape,
  Accessory,
  FitAdjustments,
} from "@/types";
import { COLOR_OPTIONS } from "./mockData";

const DEFAULT_FIT: FitAdjustments = { hairlineOffset: 0, scale: 1, rotationY: 0 };

interface SalonStore {
  photos: UserPhotos;
  setPhoto: (slot: "front" | "side", dataUrl: string) => void;

  faceShape: FaceShape | null;
  faceShapeConfidence: number | null;
  setFaceShape: (shape: FaceShape, confidence: number) => void;
  isAnalyzing: boolean;
  setIsAnalyzing: (v: boolean) => void;

  selectedHairstyle: Hairstyle | null;
  setHairstyle: (style: Hairstyle) => void;

  selectedColor: ColorOption;
  setColor: (color: ColorOption) => void;

  selectedTexture: HairTexture;
  setTexture: (texture: HairTexture) => void;

  volume: number;
  setVolume: (v: number) => void;

  selectedBeard: BeardStyle | null;
  setBeard: (beard: BeardStyle | null) => void;

  compareMode: boolean;
  toggleCompareMode: () => void;

  selectedAccessory: Accessory | null;
  setAccessory: (accessory: Accessory | null) => void;

  fit: FitAdjustments;
  setFit: (fit: Partial<FitAdjustments>) => void;
  resetFit: () => void;
}

export const useSalonStore = create<SalonStore>((set) => ({
  photos: { front: null, side: null },
  setPhoto: (slot, dataUrl) =>
    set((state) => ({ photos: { ...state.photos, [slot]: dataUrl } })),

  faceShape: null,
  faceShapeConfidence: null,
  setFaceShape: (shape, confidence) =>
    set({ faceShape: shape, faceShapeConfidence: confidence }),
  isAnalyzing: false,
  setIsAnalyzing: (v) => set({ isAnalyzing: v }),

  selectedHairstyle: null,
  setHairstyle: (style) =>
    set({ selectedHairstyle: style, selectedTexture: style.defaultTexture }),

  selectedColor: COLOR_OPTIONS[1], // castanho escuro como default
  setColor: (color) => set({ selectedColor: color }),

  selectedTexture: "liso",
  setTexture: (texture) => set({ selectedTexture: texture }),

  volume: 0.5,
  setVolume: (v) => set({ volume: v }),

  selectedBeard: null,
  setBeard: (beard) => set({ selectedBeard: beard }),

  compareMode: false,
  toggleCompareMode: () => set((state) => ({ compareMode: !state.compareMode })),

  selectedAccessory: null,
  setAccessory: (accessory) => set({ selectedAccessory: accessory }),

  fit: DEFAULT_FIT,
  setFit: (partial) => set((state) => ({ fit: { ...state.fit, ...partial } })),
  resetFit: () => set({ fit: DEFAULT_FIT }),
}));
