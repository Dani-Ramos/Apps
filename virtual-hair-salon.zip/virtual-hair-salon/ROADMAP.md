# Roadmap — Visão de longo prazo

Estas três funcionalidades exigem infraestrutura além de um protótipo front-end
(processamento de imagem mais pesado, conta de utilizador, painel B2B com
autenticação de salões). Por isso não estão implementadas como UI mock — em
vez disso, aqui vai a arquitetura pensada para cada uma, para implementação
faseada.

---

## 1. Modo "Crescimento do Cabelo" (2 e 4 semanas)

**Ideia:** simular como o corte atual vai ficar com o cabelo mais comprido.

**Arquitetura proposta:**
- Reaproveita o `HairModel.tsx` existente: crescimento = interpolação entre
  o estado atual do `scale`/geometria e um segundo preset "penteado + 4
  semanas" (ex.: o mesmo corte, mas com o parâmetro `length` do
  `Hairstyle` promovido um nível: curto → médio, ou simplesmente um
  `scale.y` maior nas pontas).
- Novo campo no tipo `Hairstyle`: `growthStages?: { weeks: number; scaleModifier: number }[]`.
- UI: um slider "0 — 2 — 4 semanas" no painel de Cor & Textura, que
  interpola `fit.scale` e o offset vertical do `HairModel` ao vivo (sem
  pedir nova foto).
- Sem necessidade de IA generativa para a v1 — é extrapolação geométrica.
  Uma v2 mais realista usaria taxa média de crescimento capilar (~1,25 cm/mês)
  aplicada à geometria real do `.glb` quando os modelos reais substituírem
  os placeholders.

---

## 2. Integração B2B para Salões

**Ideia:** painel onde o cabeleireiro vê a fórmula exata da tinta e o mapa
do corte gerados pelo cliente.

**Arquitetura proposta:**
- Requer conta/autenticação (ex.: NextAuth) e um papel `salon_owner`
  separado do utilizador final.
- Nova rota `app/salon-dashboard/` (protegida por middleware de auth),
  com uma base de dados (Postgres/Supabase) guardando cada "ficha de
  corte" gerada pelo `ExportCard` — hoje o PDF é gerado localmente e
  descartado; passaria a ser persistido com um `share_code` único.
- O cliente, em vez de só descarregar o PDF, obteria um código de 6
  dígitos para dar ao cabeleireiro; o salão introduz o código no painel e
  vê a mesma ficha técnica (corte, cor, ajustes de encaixe) online.
- `lib/exportReport.ts` já produz os dados estruturados certos
  (`ReportInput`) — a mudança seria gravar esse objeto numa tabela em vez
  de (ou além de) gerar só o PDF.

---

## 3. Biblioteca Inclusiva (afros, tranças, dreadlocks, acessórios)

**Estado atual:** já parcialmente implementado nesta versão —
`lib/mockData.ts` inclui `box-braids-longas`, `trancas-nagoa`,
`dreadlocks-medios`, `twists-senegalesas` e `afro-natural`, e há um novo
tipo `Accessory` com óculos/chapéus/lenços, renderizado por
`AccessoryModel.tsx` e controlado no painel "Encaixe".

**Próximos passos para produção:**
- Substituir os placeholders geométricos por uma biblioteca real de
  modelos `.glb` especializados nestas texturas (o crescimento capilar,
  o comportamento de fio e o volume de crespo/cacheado não se simulam
  bem com esferas — precisam de geometria e simulação de tecido/pêlo
  dedicadas, ex.: shaders de fio tipo XGen/Ornatrix exportados para glTF).
- Ampliar `FaceShapeAnalysis` para não assumir cabelo curto/liso como
  padrão visual nas recomendações — hoje as sugestões já cruzam
  `recommendedFor` por formato de rosto independentemente da textura,
  mas o texto de conselho (`FACE_SHAPE_ADVICE`) pode ganhar variantes
  por textura predominante do utilizador.
