"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { Accessory } from "@/types";

interface AccessoryModelProps {
  accessory: Accessory | null;
}

/**
 * MOCK do acessório (óculos/chapéu/lenço). Placeholder geométrico simples
 * posicionado conforme a categoria; em produção cada `accessory.modelPath`
 * carregaria o .glb correspondente via useGLTF.
 */
export default function AccessoryModel({ accessory }: AccessoryModelProps) {
  const material = useMemo(
    () => new THREE.MeshStandardMaterial({ color: "#1a1a1a", roughness: 0.3, metalness: 0.4 }),
    []
  );

  if (!accessory || accessory.id === "sem-acessorio") return null;

  if (accessory.category === "oculos") {
    return (
      <mesh position={[0, 0.02, 0.95]} material={material}>
        <torusGeometry args={[0.28, 0.035, 16, 32]} />
      </mesh>
    );
  }

  if (accessory.category === "chapeu") {
    return (
      <mesh position={[0, 0.85, 0]} material={material}>
        <cylinderGeometry args={[1.05, 1.15, 0.22, 32]} />
      </mesh>
    );
  }

  // acessorio-cabelo (lenço, presilha…)
  return (
    <mesh position={[0, 0.75, -0.3]} material={material}>
      <torusGeometry args={[0.85, 0.08, 16, 32, Math.PI]} />
    </mesh>
  );
}
