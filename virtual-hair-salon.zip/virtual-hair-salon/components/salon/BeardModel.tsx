"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { BeardStyle } from "@/types";

interface BeardModelProps {
  beard: BeardStyle | null;
  colorHex: string;
}

export default function BeardModel({ beard, colorHex }: BeardModelProps) {
  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: 0.55,
      }),
    [colorHex]
  );

  if (!beard || beard.id === "sem-barba") return null;

  return (
    <mesh position={[0, -0.55, 0.75]} material={material} castShadow>
      {/* Placeholder: volume de barba cobrindo mandíbula/queixo */}
      <sphereGeometry args={[0.62, 32, 32, 0, Math.PI * 2, Math.PI * 0.35, Math.PI * 0.55]} />
    </mesh>
  );
}
