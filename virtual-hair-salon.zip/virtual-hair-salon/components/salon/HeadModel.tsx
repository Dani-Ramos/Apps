"use client";

import { useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";

interface HeadModelProps {
  frontPhoto: string | null;
  sidePhoto: string | null;
}

/**
 * Placeholder da cabeça em 3D.
 *
 * MOCK: usamos uma geometria de cabeça genérica (esfera deformada) e
 * projetamos a foto de frente e de perfil como texturas em faces
 * diferentes, simulando um "wrap" fotográfico sobre o volume 3D.
 *
 * Em produção, isto seria substituído por:
 *   1) um modelo base de cabeça humana (.glb) escaneado/parametrizado, ou
 *   2) uma reconstrução foto-realista via fotogrametria de duas vistas
 *      (ex.: pipeline tipo "single/two-view 3D face reconstruction",
 *      gerando um mesh + textura UV a partir das duas fotos).
 * O contrato de props (frontPhoto/sidePhoto) mantém-se igual, então só
 * o interior deste componente muda quando o pipeline real for integrado.
 */
export default function HeadModel({ frontPhoto, sidePhoto }: HeadModelProps) {
  const frontTexture = useConditionalTexture(frontPhoto);
  const sideTexture = useConditionalTexture(sidePhoto);

  const skinMaterial = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: frontPhoto ? "#ffffff" : "#c9a98a",
        map: frontTexture ?? null,
        roughness: 0.65,
        metalness: 0,
      }),
    [frontTexture, frontPhoto]
  );

  const sideMaterial = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: sidePhoto ? "#ffffff" : "#c9a98a",
        map: sideTexture ?? null,
        roughness: 0.65,
        metalness: 0,
      }),
    [sideTexture, sidePhoto]
  );

  return (
    <group position={[0, 0, 0]}>
      {/* Volume base da cabeça — proporções aproximadas de um crânio adulto */}
      <mesh castShadow receiveShadow material={skinMaterial}>
        <sphereGeometry args={[1, 64, 64]} />
      </mesh>

      {/* "Face plate" frontal: recebe a foto de frente, ligeiramente à frente do volume */}
      <mesh position={[0, -0.05, 0.92]} material={skinMaterial}>
        <planeGeometry args={[1.15, 1.4]} />
      </mesh>

      {/* "Profile plate" lateral: recebe a foto de perfil */}
      <mesh position={[0.92, -0.05, 0]} rotation={[0, Math.PI / 2, 0]} material={sideMaterial}>
        <planeGeometry args={[1.3, 1.4]} />
      </mesh>

      {/* Pescoço simplificado, para o modelo não "flutuar" */}
      <mesh position={[0, -1.15, 0]}>
        <cylinderGeometry args={[0.35, 0.45, 0.6, 32]} />
        <meshStandardMaterial color="#c9a98a" roughness={0.7} />
      </mesh>
    </group>
  );
}

function useConditionalTexture(dataUrl: string | null) {
  // useTexture do drei espera uma URL válida; quando não há foto ainda,
  // usamos um pixel transparente em vez de condicionar o hook (regra dos hooks).
  const safeUrl =
    dataUrl ?? "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+A8AAQUBAScY42YAAAAASUVORK5CYII=";
  const texture = useTexture(safeUrl);
  return dataUrl ? texture : null;
}
