"use client";

import { Suspense } from "react";
import { Canvas } from "@react-three/fiber";
import { OrbitControls, Environment, ContactShadows, Html } from "@react-three/drei";
import HeadModel from "./HeadModel";
import HairModel from "./HairModel";
import BeardModel from "./BeardModel";
import AccessoryModel from "./AccessoryModel";
import { useSalonStore } from "@/lib/store";

/**
 * Setup completo da cena 3D.
 *
 * - Câmera perspectiva com limites de zoom/rotação pensados para "girar
 *   ao redor de uma cabeça" sem deixar o utilizador perder o enquadramento.
 * - Luz principal (key light) simulando o clássico "espelho de camarim"
 *   com temperatura quente, + luz de preenchimento fria para não achatar
 *   o rosto.
 * - `ContactShadows` para dar chão/profundidade sem precisar de um mesh
 *   de chão explícito.
 */
export default function Scene3D() {
  const {
    photos,
    selectedHairstyle,
    selectedColor,
    selectedTexture,
    volume,
    selectedBeard,
    selectedAccessory,
    fit,
  } = useSalonStore();

  return (
    <Canvas
      shadows
      dpr={[1, 2]}
      camera={{ position: [0, 0.1, 3.2], fov: 35 }}
      gl={{ preserveDrawingBuffer: true }} // necessário para exportar snapshot em PNG/PDF
    >
      {/* Fundo neutro escuro para contrastar com a moldura do "espelho" no DOM */}
      <color attach="background" args={["#0b0a0c"]} />

      {/* Luz-chave quente, tipo lâmpada de camarim */}
      <spotLight
        position={[2.5, 3, 3]}
        angle={0.35}
        penumbra={0.6}
        intensity={2.2}
        color="#f4dfb8"
        castShadow
        shadow-mapSize={[1024, 1024]}
      />
      {/* Luz de preenchimento fria, suave, do lado oposto */}
      <pointLight position={[-2.5, 1, -1.5]} intensity={0.5} color="#8ab0c9" />
      {/* Luz ambiente muito baixa para não estourar os pretos */}
      <ambientLight intensity={0.18} />

      <Suspense
        fallback={
          <Html center>
            <div className="text-sm text-[var(--text-muted)] font-mono-tech">a carregar modelo…</div>
          </Html>
        }
      >
        <group position={[0, -0.1, 0]}>
          <HeadModel frontPhoto={photos.front} sidePhoto={photos.side} />
          <HairModel
            hairstyle={selectedHairstyle}
            colorHex={selectedColor.hex}
            texture={selectedTexture}
            volume={volume}
            fit={fit}
          />
          <BeardModel beard={selectedBeard} colorHex={selectedColor.hex} />
          <AccessoryModel accessory={selectedAccessory} />
        </group>

        <Environment preset="apartment" />
        <ContactShadows position={[0, -1.5, 0]} opacity={0.5} scale={6} blur={2.5} far={2} />
      </Suspense>

      {/* Controles: rotação livre 360°, zoom limitado para não "entrar" na cabeça */}
      <OrbitControls
        enablePan={false}
        minDistance={1.8}
        maxDistance={4.5}
        minPolarAngle={Math.PI / 3.2}
        maxPolarAngle={Math.PI / 1.6}
        autoRotate={!selectedHairstyle}
        autoRotateSpeed={1.1}
        target={[0, -0.1, 0]}
      />
    </Canvas>
  );
}
