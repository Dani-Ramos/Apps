"use client";

import dynamic from "next/dynamic";

const Scene3D = dynamic(() => import("./Scene3D"), { ssr: false });

const BULB_COUNT = 14;

/**
 * Elemento de assinatura da interface: o viewport 3D é apresentado dentro
 * de uma moldura oval de "espelho de camarim", com lâmpadas ao redor.
 * Isto ancora a metáfora do produto (experimentar penteados como se
 * estivesse sentado numa cadeira de salão, olhando para o espelho).
 */
export default function MirrorViewport() {
  return (
    <div className="relative mx-auto aspect-[4/5] w-full max-w-[560px]">
      {/* Moldura */}
      <div
        className="absolute inset-0 rounded-[46%] p-[14px]"
        style={{
          background: "linear-gradient(155deg, #C9A15E, #7a5e34 55%, #C9A15E)",
          boxShadow:
            "0 0 0 1px rgba(201,161,94,0.35), 0 20px 60px -20px rgba(0,0,0,0.8), inset 0 0 20px rgba(0,0,0,0.4)",
        }}
      >
        <div className="relative h-full w-full overflow-hidden rounded-[42%] bg-black">
          <Scene3D />
        </div>
      </div>

      {/* Lâmpadas distribuídas pelo perímetro oval */}
      {Array.from({ length: BULB_COUNT }).map((_, i) => {
        const angle = (i / BULB_COUNT) * Math.PI * 2;
        const rx = 50; // raio horizontal em %
        const ry = 50; // raio vertical em %
        const x = 50 + rx * Math.cos(angle);
        const y = 50 + ry * Math.sin(angle);
        return (
          <span
            key={i}
            className="mirror-bulb mirror-bulb-animate absolute h-2.5 w-2.5 -translate-x-1/2 -translate-y-1/2 rounded-full bg-[var(--gold-soft)]"
            style={{
              left: `${x}%`,
              top: `${y}%`,
              animationDelay: `${i * 45}ms`,
            }}
          />
        );
      })}
    </div>
  );
}
