"use client";

import { useMemo, useRef } from "react";
import { useFrame } from "@react-three/fiber";
import * as THREE from "three";
import { Hairstyle, HairTexture, FitAdjustments } from "@/types";

interface HairModelProps {
  hairstyle: Hairstyle | null;
  colorHex: string;
  texture: HairTexture;
  volume: number; // 0 - 1
  fit: FitAdjustments;
}

/**
 * MOCK do penteado em 3D.
 *
 * Em produção: cada `hairstyle.modelPath` apontaria para um .glb real,
 * carregado via `useGLTF`, com morph targets para "volume" e um mesh
 * único cujo material.color/roughness são controlados ao vivo — exatamente
 * como já fazemos aqui, para que o componente não precise mudar de forma
 * quando os modelos reais forem plugados.
 *
 * A "textura" (liso/ondulado/cacheado/crespo) altera roughness + um
 * leve ruído de geometria para sugerir volume/tessitura sem precisar de
 * um mesh dedicado por textura.
 */
export default function HairModel({ hairstyle, colorHex, texture, volume, fit }: HairModelProps) {
  const meshRef = useRef<THREE.Mesh>(null);

  const roughnessByTexture: Record<HairTexture, number> = {
    liso: 0.25,
    ondulado: 0.45,
    cacheado: 0.6,
    crespo: 0.75,
  };

  const scaleByLength = useMemo(() => {
    if (!hairstyle) return 1;
    return hairstyle.length === "longo" ? 1.35 : hairstyle.length === "medio" ? 1.12 : 0.95;
  }, [hairstyle]);

  const material = useMemo(
    () =>
      new THREE.MeshStandardMaterial({
        color: colorHex,
        roughness: roughnessByTexture[texture],
        metalness: 0.05,
      }),
    [colorHex, texture]
  );

  // Pequena "respiração" para o penteado não parecer estático/plástico,
  // combinada com os ajustes manuais de encaixe (escala e rotação).
  useFrame((state) => {
    if (!meshRef.current) return;
    const t = state.clock.getElapsedTime();
    const breathing = 1 + Math.sin(t * 0.6) * 0.008;
    const manualScale = fit.scale;
    meshRef.current.scale.set(
      scaleByLength * (1 + volume * 0.35) * breathing * manualScale,
      scaleByLength * (1 + volume * 0.2) * breathing * manualScale,
      scaleByLength * (1 + volume * 0.35) * breathing * manualScale
    );
    meshRef.current.rotation.y = THREE.MathUtils.degToRad(fit.rotationY);
    // hairlineOffset desloca o penteado ao longo do eixo Z (para a frente/trás
    // da testa), simulando ajuste manual da linha de nascimento do cabelo.
    meshRef.current.position.z = -0.05 + fit.hairlineOffset * 0.12;
  });

  if (!hairstyle) return null;

  return (
    <mesh ref={meshRef} position={[0, 0.55, -0.05]} material={material} castShadow>
      {/* Placeholder geométrico do volume de cabelo; substituído pelo .glb real */}
      <sphereGeometry args={[0.98, 48, 48, 0, Math.PI * 2, 0, Math.PI * 0.62]} />
    </mesh>
  );
}
