"use client";

import { useRef } from "react";
import { useSalonStore } from "@/lib/store";
import { analyzeFaceShape } from "@/lib/faceShapeAnalysis";

function readFileAsDataUrl(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result as string);
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

interface SlotProps {
  slot: "front" | "side";
  label: string;
  hint: string;
}

function UploadSlot({ slot, label, hint }: SlotProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const photo = useSalonStore((s) => s.photos[slot]);
  const setPhoto = useSalonStore((s) => s.setPhoto);
  const setFaceShape = useSalonStore((s) => s.setFaceShape);
  const setIsAnalyzing = useSalonStore((s) => s.setIsAnalyzing);

  const handleFile = async (file: File) => {
    const dataUrl = await readFileAsDataUrl(file);
    setPhoto(slot, dataUrl);

    if (slot === "front") {
      setIsAnalyzing(true);
      const result = await analyzeFaceShape(dataUrl);
      setFaceShape(result.shape, result.confidence);
      setIsAnalyzing(false);
    }
  };

  return (
    <button
      type="button"
      onClick={() => inputRef.current?.click()}
      className="group relative flex aspect-[3/4] w-full flex-col items-center justify-center gap-2 rounded-2xl border border-[var(--line)] bg-[var(--surface)] transition-colors hover:border-[var(--gold)] focus-visible:outline focus-visible:outline-2 focus-visible:outline-[var(--gold)]"
    >
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        capture="user"
        className="hidden"
        onChange={(e) => {
          const file = e.target.files?.[0];
          if (file) handleFile(file);
        }}
      />
      {photo ? (
        // eslint-disable-next-line @next/next/no-img-element
        <img src={photo} alt={label} className="absolute inset-0 h-full w-full rounded-2xl object-cover" />
      ) : (
        <>
          <div className="flex h-11 w-11 items-center justify-center rounded-full border border-[var(--gold)] text-[var(--gold)]">
            +
          </div>
          <span className="font-display text-base">{label}</span>
          <span className="max-w-[80%] text-center text-xs text-[var(--text-muted)]">{hint}</span>
        </>
      )}
      {photo && (
        <span className="absolute bottom-2 right-2 rounded-full bg-black/60 px-2 py-1 text-xs backdrop-blur">
          trocar foto
        </span>
      )}
    </button>
  );
}

export default function DualPhotoUpload() {
  return (
    <div className="grid grid-cols-2 gap-3">
      <UploadSlot slot="front" label="De frente" hint="Rosto centrado, olhando para a câmara" />
      <UploadSlot slot="side" label="De perfil" hint="Vire a cabeça 90°, orelha visível" />
    </div>
  );
}
