"use client";

import { useMemo } from "react";
import { useSalonStore } from "@/lib/store";
import { recommendProductsForTexture } from "@/lib/mockData";

const TYPE_LABELS: Record<string, string> = {
  pomada: "Pomada",
  oleo: "Óleo",
  tinta: "Tinta",
  mousse: "Mousse",
  "spray-fixador": "Spray fixador",
};

export default function ProductRecommendations() {
  const texture = useSalonStore((s) => s.selectedTexture);
  const hairstyle = useSalonStore((s) => s.selectedHairstyle);

  const products = useMemo(() => recommendProductsForTexture(texture), [texture]);

  if (!hairstyle) {
    return (
      <div className="panel-glass rounded-2xl p-4">
        <h3 className="font-display text-base">Produtos recomendados</h3>
        <p className="mt-2 text-xs text-[var(--text-muted)]">
          Escolha um penteado no catálogo para ver sugestões de produtos de styling.
        </p>
      </div>
    );
  }

  return (
    <div className="panel-glass rounded-2xl p-4">
      <h3 className="font-display text-base">Produtos recomendados</h3>
      <p className="mt-1 text-xs text-[var(--text-muted)]">
        Sugestões com base na textura <span className="text-[var(--gold-soft)]">{texture}</span> do
        seu penteado.
      </p>

      <div className="mt-3 space-y-2.5">
        {products.map((p) => (
          <div
            key={p.id}
            className="flex gap-3 rounded-xl border border-[var(--line)] bg-[var(--surface)] p-2.5"
          >
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-lg bg-[var(--surface-raised)] font-mono-tech text-[9px] text-[var(--text-muted)]">
              foto
            </div>
            <div className="min-w-0 flex-1">
              <div className="flex items-center justify-between gap-2">
                <p className="truncate text-sm">{p.name}</p>
                <span className="shrink-0 rounded-full bg-[var(--copper)]/25 px-2 py-0.5 text-[10px] text-[var(--gold-soft)]">
                  {TYPE_LABELS[p.type]}
                </span>
              </div>
              <p className="text-[11px] text-[var(--text-muted)]">{p.brand}</p>
              <p className="mt-0.5 text-[11px] text-[var(--text-muted)]">{p.description}</p>
            </div>
          </div>
        ))}
      </div>

      <p className="mt-3 text-center text-[10px] text-[var(--text-muted)]">
        Sugestões editoriais — sem parceria comercial ativa neste protótipo.
      </p>
    </div>
  );
}
