"use client";

import { HairLength, HairStyleTag, Gender } from "@/types";

interface FilterState {
  length: HairLength | "todos";
  style: HairStyleTag | "todos";
  gender: Gender | "todos";
}

interface FilterBarProps {
  value: FilterState;
  onChange: (value: FilterState) => void;
}

const LENGTHS: { id: FilterState["length"]; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "curto", label: "Curto" },
  { id: "medio", label: "Médio" },
  { id: "longo", label: "Longo" },
];

const STYLES: { id: FilterState["style"]; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "casual", label: "Casual" },
  { id: "formal", label: "Formal" },
  { id: "moderno", label: "Moderno" },
  { id: "classico", label: "Clássico" },
];

const GENDERS: { id: FilterState["gender"]; label: string }[] = [
  { id: "todos", label: "Todos" },
  { id: "feminino", label: "Feminino" },
  { id: "masculino", label: "Masculino" },
  { id: "unissexo", label: "Unissexo" },
];

function ChipRow<T extends string>({
  options,
  active,
  onSelect,
}: {
  options: { id: T; label: string }[];
  active: T;
  onSelect: (id: T) => void;
}) {
  return (
    <div className="flex gap-2 overflow-x-auto pb-1">
      {options.map((opt) => (
        <button
          key={opt.id}
          onClick={() => onSelect(opt.id)}
          className={`shrink-0 rounded-full border px-3 py-1.5 text-xs transition-colors ${
            active === opt.id
              ? "border-[var(--gold)] bg-[var(--gold)] text-black"
              : "border-[var(--line)] text-[var(--text-muted)] hover:border-[var(--gold)] hover:text-[var(--text)]"
          }`}
        >
          {opt.label}
        </button>
      ))}
    </div>
  );
}

export default function FilterBar({ value, onChange }: FilterBarProps) {
  return (
    <div className="space-y-2.5">
      <ChipRow options={LENGTHS} active={value.length} onSelect={(length) => onChange({ ...value, length })} />
      <ChipRow options={STYLES} active={value.style} onSelect={(style) => onChange({ ...value, style })} />
      <ChipRow options={GENDERS} active={value.gender} onSelect={(gender) => onChange({ ...value, gender })} />
    </div>
  );
}

export type { FilterState };
