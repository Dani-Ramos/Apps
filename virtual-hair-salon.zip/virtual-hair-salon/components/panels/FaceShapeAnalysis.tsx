"use client";

import { useSalonStore } from "@/lib/store";
import { FACE_SHAPE_ADVICE, FACE_SHAPE_LABELS } from "@/lib/faceShapeAnalysis";

export default function FaceShapeAnalysis() {
  const faceShape = useSalonStore((s) => s.faceShape);
  const confidence = useSalonStore((s) => s.faceShapeConfidence);
  const isAnalyzing = useSalonStore((s) => s.isAnalyzing);

  if (isAnalyzing) {
    return (
      <div className="panel-glass rounded-2xl p-4">
        <div className="flex items-center gap-3">
          <div className="h-2 w-2 animate-pulse rounded-full bg-[var(--gold)]" />
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">
            a analisar o formato do rosto…
          </span>
        </div>
      </div>
    );
  }

  if (!faceShape) return null;

  return (
    <div className="panel-glass rounded-2xl p-4">
      <div className="flex items-baseline justify-between">
        <h3 className="font-display text-lg">Formato do rosto</h3>
        {confidence && (
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">
            {Math.round(confidence * 100)}% confiança
          </span>
        )}
      </div>
      <p className="mt-1 font-display text-2xl italic text-[var(--gold-soft)]">
        {FACE_SHAPE_LABELS[faceShape]}
      </p>
      <p className="mt-2 text-sm text-[var(--text-muted)]">{FACE_SHAPE_ADVICE[faceShape]}</p>
    </div>
  );
}
