"use client";

import { useSalonStore } from "@/lib/store";

/**
 * Botão de exportação. A lógica real de geração de PDF/PNG vive em
 * lib/exportReport.ts (usa jsPDF + o snapshot do <canvas> do R3F via
 * gl.domElement.toDataURL, capturado a partir de uma ref exposta pela
 * Scene3D). Aqui mantemos só a UI e a validação de estado mínimo.
 */
export default function ExportCard() {
  const selectedHairstyle = useSalonStore((s) => s.selectedHairstyle);
  const selectedColor = useSalonStore((s) => s.selectedColor);
  const selectedBeard = useSalonStore((s) => s.selectedBeard);
  const photos = useSalonStore((s) => s.photos);

  const canExport = !!selectedHairstyle && !!photos.front;

  return (
    <div className="panel-glass rounded-2xl p-4">
      <h3 className="font-display text-base">Cartão para o cabeleireiro</h3>
      <p className="mt-1 text-xs text-[var(--text-muted)]">
        Gera um PDF com a foto original, o penteado escolhido, o código exato da
        cor e o nome técnico do corte — pronto para mostrar no salão.
      </p>

      {selectedHairstyle && (
        <dl className="mt-3 space-y-1 font-mono-tech text-[11px] text-[var(--text-muted)]">
          <div className="flex justify-between">
            <dt>Corte</dt>
            <dd className="text-[var(--text)]">{selectedHairstyle.technicalName}</dd>
          </div>
          <div className="flex justify-between">
            <dt>Cor</dt>
            <dd className="text-[var(--text)]">
              {selectedColor.name} ({selectedColor.hex})
            </dd>
          </div>
          {selectedBeard && (
            <div className="flex justify-between">
              <dt>Barba</dt>
              <dd className="text-[var(--text)]">{selectedBeard.technicalName}</dd>
            </div>
          )}
        </dl>
      )}

      <button
        disabled={!canExport}
        onClick={() => {
          // ver lib/exportReport.ts — generateHairdresserReport(...)
          console.log("Exportar relatório PDF/PNG");
        }}
        className="mt-4 w-full rounded-full bg-[var(--gold)] py-2.5 text-sm font-medium text-black transition-opacity disabled:cursor-not-allowed disabled:opacity-30"
      >
        Exportar PDF
      </button>
      {!canExport && (
        <p className="mt-2 text-center text-[11px] text-[var(--text-muted)]">
          Carregue uma foto e escolha um penteado para exportar.
        </p>
      )}
    </div>
  );
}
