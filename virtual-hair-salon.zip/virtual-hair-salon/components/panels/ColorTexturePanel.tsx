"use client";

import { COLOR_OPTIONS, BEARD_STYLES } from "@/lib/mockData";
import { useSalonStore } from "@/lib/store";
import { HairTexture } from "@/types";

const TEXTURES: { id: HairTexture; label: string }[] = [
  { id: "liso", label: "Liso" },
  { id: "ondulado", label: "Ondulado" },
  { id: "cacheado", label: "Cacheado" },
  { id: "crespo", label: "Crespo" },
];

export default function ColorTexturePanel() {
  const selectedColor = useSalonStore((s) => s.selectedColor);
  const setColor = useSalonStore((s) => s.setColor);
  const selectedTexture = useSalonStore((s) => s.selectedTexture);
  const setTexture = useSalonStore((s) => s.setTexture);
  const volume = useSalonStore((s) => s.volume);
  const setVolume = useSalonStore((s) => s.setVolume);
  const selectedBeard = useSalonStore((s) => s.selectedBeard);
  const setBeard = useSalonStore((s) => s.setBeard);

  const grouped = {
    natural: COLOR_OPTIONS.filter((c) => c.category === "natural"),
    luzes: COLOR_OPTIONS.filter((c) => c.category === "luzes"),
    fantasia: COLOR_OPTIONS.filter((c) => c.category === "fantasia"),
  };

  return (
    <div className="panel-glass space-y-5 rounded-2xl p-4">
      <div>
        <h3 className="font-display text-base">Cor</h3>
        <p className="mb-2 font-mono-tech text-[11px] text-[var(--text-muted)]">
          {selectedColor.name} · {selectedColor.hex}
        </p>
        {Object.entries(grouped).map(([category, colors]) => (
          <div key={category} className="mb-2">
            <p className="mb-1 text-[11px] capitalize text-[var(--text-muted)]">{category}</p>
            <div className="flex flex-wrap gap-2">
              {colors.map((color) => (
                <button
                  key={color.id}
                  onClick={() => setColor(color)}
                  aria-label={color.name}
                  className={`h-8 w-8 rounded-full border-2 transition-transform hover:scale-110 ${
                    selectedColor.id === color.id ? "border-[var(--gold)]" : "border-transparent"
                  }`}
                  style={{ backgroundColor: color.hex }}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      <div>
        <h3 className="mb-2 font-display text-base">Textura</h3>
        <div className="flex flex-wrap gap-2">
          {TEXTURES.map((t) => (
            <button
              key={t.id}
              onClick={() => setTexture(t.id)}
              className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                selectedTexture === t.id
                  ? "border-[var(--gold)] bg-[var(--gold)] text-black"
                  : "border-[var(--line)] text-[var(--text-muted)] hover:text-[var(--text)]"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="font-display text-base">Volume</h3>
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">
            {Math.round(volume * 100)}%
          </span>
        </div>
        <input
          type="range"
          min={0}
          max={1}
          step={0.01}
          value={volume}
          onChange={(e) => setVolume(Number(e.target.value))}
          className="w-full accent-[var(--gold)]"
        />
      </div>

      <div>
        <h3 className="mb-2 font-display text-base">Barba</h3>
        <div className="flex flex-wrap gap-2">
          {BEARD_STYLES.map((beard) => (
            <button
              key={beard.id}
              onClick={() => setBeard(beard.id === "sem-barba" ? null : beard)}
              className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                (selectedBeard?.id ?? "sem-barba") === beard.id
                  ? "border-[var(--gold)] bg-[var(--gold)] text-black"
                  : "border-[var(--line)] text-[var(--text-muted)] hover:text-[var(--text)]"
              }`}
            >
              {beard.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
