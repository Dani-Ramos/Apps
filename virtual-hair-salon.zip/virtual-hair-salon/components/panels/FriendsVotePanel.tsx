"use client";

import { useState } from "react";
import { useSalonStore } from "@/lib/store";
import { buildVoteLink, getMockVotes } from "@/lib/shareVote";

export default function FriendsVotePanel() {
  const hairstyle = useSalonStore((s) => s.selectedHairstyle);
  const color = useSalonStore((s) => s.selectedColor);
  const [link, setLink] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  if (!hairstyle) {
    return (
      <div className="panel-glass rounded-2xl p-4">
        <h3 className="font-display text-base">Opinião dos amigos</h3>
        <p className="mt-2 text-xs text-[var(--text-muted)]">
          Escolha um penteado para gerar um link de votação e partilhar nas redes sociais.
        </p>
      </div>
    );
  }

  const votes = getMockVotes(hairstyle.id);
  const total = votes.yes + votes.no || 1;
  const yesPct = Math.round((votes.yes / total) * 100);

  const handleGenerate = () => {
    setLink(buildVoteLink(hairstyle, color));
    setCopied(false);
  };

  const handleCopy = async () => {
    if (!link) return;
    await navigator.clipboard.writeText(link);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleShare = async () => {
    if (!link) return;
    if (navigator.share) {
      await navigator.share({
        title: "Ajuda-me a escolher este penteado!",
        text: `O que achas deste look — ${hairstyle.name}?`,
        url: link,
      });
    } else {
      handleCopy();
    }
  };

  return (
    <div className="panel-glass rounded-2xl p-4">
      <h3 className="font-display text-base">Opinião dos amigos</h3>
      <p className="mt-1 text-xs text-[var(--text-muted)]">
        Gere um link de votação rápida para partilhar no Instagram, WhatsApp ou onde quiser.
      </p>

      {!link ? (
        <button
          onClick={handleGenerate}
          className="mt-3 w-full rounded-full bg-[var(--gold)] py-2.5 text-sm font-medium text-black"
        >
          Gerar link de votação
        </button>
      ) : (
        <div className="mt-3 space-y-2">
          <div className="truncate rounded-lg border border-[var(--line)] bg-[var(--surface)] px-3 py-2 font-mono-tech text-[11px] text-[var(--text-muted)]">
            {link}
          </div>
          <div className="flex gap-2">
            <button
              onClick={handleCopy}
              className="flex-1 rounded-full border border-[var(--gold)] py-2 text-xs text-[var(--gold-soft)]"
            >
              {copied ? "Copiado!" : "Copiar link"}
            </button>
            <button
              onClick={handleShare}
              className="flex-1 rounded-full bg-[var(--gold)] py-2 text-xs font-medium text-black"
            >
              Partilhar
            </button>
          </div>
        </div>
      )}

      {(votes.yes > 0 || votes.no > 0) && (
        <div className="mt-4">
          <div className="mb-1 flex justify-between text-[11px] text-[var(--text-muted)]">
            <span>{votes.yes} gostaram</span>
            <span>{votes.no} não gostaram</span>
          </div>
          <div className="h-1.5 w-full overflow-hidden rounded-full bg-[var(--line)]">
            <div className="h-full bg-[var(--confirm)]" style={{ width: `${yesPct}%` }} />
          </div>
        </div>
      )}

      <p className="mt-3 text-[10px] text-[var(--text-muted)]">
        Contagem de votos guardada localmente neste protótipo — uma versão em
        produção usaria uma rota de API para agregar votos entre dispositivos.
      </p>
    </div>
  );
}
