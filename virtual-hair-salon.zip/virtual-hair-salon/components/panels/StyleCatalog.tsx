"use client";

import { useMemo, useState } from "react";
import { HAIRSTYLES } from "@/lib/mockData";
import { useSalonStore } from "@/lib/store";
import FilterBar, { FilterState } from "./FilterBar";

export default function StyleCatalog() {
  const [filters, setFilters] = useState<FilterState>({
    length: "todos",
    style: "todos",
    gender: "todos",
  });

  const faceShape = useSalonStore((s) => s.faceShape);
  const selectedHairstyle = useSalonStore((s) => s.selectedHairstyle);
  const setHairstyle = useSalonStore((s) => s.setHairstyle);

  const filtered = useMemo(() => {
    return HAIRSTYLES.filter((h) => {
      if (filters.length !== "todos" && h.length !== filters.length) return false;
      if (filters.style !== "todos" && !h.tags.includes(filters.style)) return false;
      if (filters.gender !== "todos" && h.gender !== filters.gender && h.gender !== "unissexo")
        return false;
      return true;
    }).sort((a, b) => {
      if (!faceShape) return 0;
      const aRec = a.recommendedFor.includes(faceShape) ? 1 : 0;
      const bRec = b.recommendedFor.includes(faceShape) ? 1 : 0;
      return bRec - aRec;
    });
  }, [filters, faceShape]);

  return (
    <div className="space-y-3">
      <FilterBar value={filters} onChange={setFilters} />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
        {filtered.map((style) => {
          const isRecommended = faceShape ? style.recommendedFor.includes(faceShape) : false;
          const isSelected = selectedHairstyle?.id === style.id;
          return (
            <button
              key={style.id}
              onClick={() => setHairstyle(style)}
              className={`group relative flex flex-col overflow-hidden rounded-xl border text-left transition-colors ${
                isSelected
                  ? "border-[var(--gold)]"
                  : "border-[var(--line)] hover:border-[var(--gold)]/60"
              }`}
            >
              <div className="flex aspect-square items-center justify-center bg-[var(--surface)] font-mono-tech text-[10px] text-[var(--text-muted)]">
                thumbnail
              </div>
              <div className="p-2.5">
                <p className="font-display text-sm leading-tight">{style.name}</p>
                {isRecommended && (
                  <span className="mt-1 inline-block rounded-full bg-[var(--confirm)]/25 px-2 py-0.5 text-[10px] text-[#8fcbb8]">
                    Recomendado
                  </span>
                )}
              </div>
            </button>
          );
        })}
      </div>

      {filtered.length === 0 && (
        <p className="py-8 text-center text-sm text-[var(--text-muted)]">
          Nenhum penteado com estes filtros. Experimente ajustar comprimento ou estilo.
        </p>
      )}
    </div>
  );
}
