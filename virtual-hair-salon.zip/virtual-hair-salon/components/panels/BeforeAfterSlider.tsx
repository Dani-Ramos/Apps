"use client";

import { useState } from "react";
import { useSalonStore } from "@/lib/store";

export default function BeforeAfterSlider() {
  const [position, setPosition] = useState(50);
  const photos = useSalonStore((s) => s.photos);

  if (!photos.front) return null;

  return (
    <div className="panel-glass rounded-2xl p-4">
      <h3 className="mb-3 font-display text-base">Antes / Depois</h3>
      <div className="relative aspect-[4/5] overflow-hidden rounded-xl">
        {/* eslint-disable-next-line @next/next/no-img-element */}
        <img src={photos.front} alt="Foto original" className="absolute inset-0 h-full w-full object-cover" />
        <div
          className="absolute inset-0 flex items-center justify-center bg-[var(--surface)]/95 font-mono-tech text-[11px] text-[var(--text-muted)]"
          style={{ clipPath: `inset(0 0 0 ${position}%)` }}
        >
          simulação 3D (render do canvas)
        </div>
        <div
          className="absolute inset-y-0 w-0.5 bg-[var(--gold)]"
          style={{ left: `${position}%` }}
        />
      </div>
      <input
        type="range"
        min={0}
        max={100}
        value={position}
        onChange={(e) => setPosition(Number(e.target.value))}
        className="mt-3 w-full accent-[var(--gold)]"
        aria-label="Comparar antes e depois"
      />
    </div>
  );
}
