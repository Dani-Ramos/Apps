"use client";

import { useSalonStore } from "@/lib/store";
import { ACCESSORIES } from "@/lib/mockData";

export default function FitAdjustPanel() {
  const fit = useSalonStore((s) => s.fit);
  const setFit = useSalonStore((s) => s.setFit);
  const resetFit = useSalonStore((s) => s.resetFit);
  const selectedAccessory = useSalonStore((s) => s.selectedAccessory);
  const setAccessory = useSalonStore((s) => s.setAccessory);

  return (
    <div className="panel-glass space-y-5 rounded-2xl p-4">
      <div className="flex items-baseline justify-between">
        <h3 className="font-display text-base">Ajuste fino de encaixe</h3>
        <button
          onClick={resetFit}
          className="font-mono-tech text-[11px] text-[var(--text-muted)] underline decoration-dotted hover:text-[var(--gold)]"
        >
          repor padrão
        </button>
      </div>
      <p className="-mt-3 text-xs text-[var(--text-muted)]">
        Afine manualmente o encaixe do penteado se o ajuste automático não ficar perfeito.
      </p>

      <div>
        <div className="mb-1 flex items-center justify-between">
          <label className="text-sm">Linha da testa</label>
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">
            {fit.hairlineOffset > 0 ? "+" : ""}
            {fit.hairlineOffset.toFixed(2)}
          </span>
        </div>
        <input
          type="range"
          min={-1}
          max={1}
          step={0.01}
          value={fit.hairlineOffset}
          onChange={(e) => setFit({ hairlineOffset: Number(e.target.value) })}
          className="w-full accent-[var(--gold)]"
        />
        <div className="mt-0.5 flex justify-between text-[10px] text-[var(--text-muted)]">
          <span>recuado</span>
          <span>avançado</span>
        </div>
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between">
          <label className="text-sm">Escala</label>
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">
            {Math.round(fit.scale * 100)}%
          </span>
        </div>
        <input
          type="range"
          min={0.8}
          max={1.3}
          step={0.01}
          value={fit.scale}
          onChange={(e) => setFit({ scale: Number(e.target.value) })}
          className="w-full accent-[var(--gold)]"
        />
      </div>

      <div>
        <div className="mb-1 flex items-center justify-between">
          <label className="text-sm">Rotação</label>
          <span className="font-mono-tech text-xs text-[var(--text-muted)]">{fit.rotationY}°</span>
        </div>
        <input
          type="range"
          min={-20}
          max={20}
          step={1}
          value={fit.rotationY}
          onChange={(e) => setFit({ rotationY: Number(e.target.value) })}
          className="w-full accent-[var(--gold)]"
        />
      </div>

      <div>
        <h4 className="mb-2 text-sm">Acessórios</h4>
        <div className="flex flex-wrap gap-2">
          {ACCESSORIES.map((acc) => (
            <button
              key={acc.id}
              onClick={() => setAccessory(acc.id === "sem-acessorio" ? null : acc)}
              className={`rounded-full border px-3 py-1.5 text-xs transition-colors ${
                (selectedAccessory?.id ?? "sem-acessorio") === acc.id
                  ? "border-[var(--gold)] bg-[var(--gold)] text-black"
                  : "border-[var(--line)] text-[var(--text-muted)] hover:text-[var(--text)]"
              }`}
            >
              {acc.name}
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
