export type FaceShape = "oval" | "quadrado" | "redondo" | "diamante" | "coracao" | "alongado";

export type HairLength = "curto" | "medio" | "longo";
export type HairStyleTag = "casual" | "formal" | "moderno" | "classico";
export type HairTexture = "liso" | "ondulado" | "cacheado" | "crespo";
export type Gender = "feminino" | "masculino" | "unissexo";

export interface Hairstyle {
  id: string;
  name: string;          // nome popular
  technicalName: string; // nome técnico, para o cartão do cabeleireiro
  length: HairLength;
  tags: HairStyleTag[];
  gender: Gender;
  defaultTexture: HairTexture;
  recommendedFor: FaceShape[];
  modelPath: string;     // caminho do .glb (mock)
  thumbnail: string;
}

export interface ColorOption {
  id: string;
  name: string;
  hex: string;
  category: "natural" | "fantasia" | "luzes";
}

export interface BeardStyle {
  id: string;
  name: string;
  technicalName: string;
  modelPath: string;
}

export interface Accessory {
  id: string;
  name: string;
  category: "oculos" | "chapeu" | "acessorio-cabelo";
  modelPath: string;
}

export interface StylingProduct {
  id: string;
  name: string;
  brand: string;
  type: "pomada" | "oleo" | "tinta" | "mousse" | "spray-fixador";
  usedFor: HairTexture[];
  description: string;
  imageUrl: string;
}

/** Ajuste manual de encaixe do penteado sobre a cabeça do utilizador */
export interface FitAdjustments {
  hairlineOffset: number; // -1 (recuado) a 1 (avançado), 0 = padrão
  scale: number;          // 0.8 - 1.3, 1 = padrão
  rotationY: number;      // graus, -20 a 20
}

export interface UserPhotos {
  front: string | null;  // data URL
  side: string | null;   // data URL
}

export interface SimulationState {
  faceShape: FaceShape | null;
  selectedHairstyle: Hairstyle | null;
  selectedColor: ColorOption | null;
  selectedTexture: HairTexture;
  volume: number;        // 0 - 1
  selectedBeard: BeardStyle | null;
}
