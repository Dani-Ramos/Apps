"use client";

import { useState } from "react";
import MirrorViewport from "@/components/salon/MirrorViewport";
import DualPhotoUpload from "@/components/upload/DualPhotoUpload";
import FaceShapeAnalysis from "@/components/panels/FaceShapeAnalysis";
import StyleCatalog from "@/components/panels/StyleCatalog";
import ColorTexturePanel from "@/components/panels/ColorTexturePanel";
import BeforeAfterSlider from "@/components/panels/BeforeAfterSlider";
import ExportCard from "@/components/panels/ExportCard";
import FitAdjustPanel from "@/components/panels/FitAdjustPanel";
import ProductRecommendations from "@/components/panels/ProductRecommendations";
import FriendsVotePanel from "@/components/panels/FriendsVotePanel";
import { useSalonStore } from "@/lib/store";

type Tab = "catalogo" | "cor" | "encaixe" | "comparar" | "produtos" | "partilhar" | "exportar";

const TABS: { id: Tab; label: string }[] = [
  { id: "catalogo", label: "Catálogo" },
  { id: "cor", label: "Cor & Textura" },
  { id: "encaixe", label: "Encaixe" },
  { id: "comparar", label: "Comparar" },
  { id: "produtos", label: "Produtos" },
  { id: "partilhar", label: "Amigos" },
  { id: "exportar", label: "Exportar" },
];

export default function VirtualHairSalonPage() {
  const [tab, setTab] = useState<Tab>("catalogo");
  const photos = useSalonStore((s) => s.photos);
  const hasBothPhotos = !!photos.front && !!photos.side;

  return (
    <main className="mx-auto min-h-screen max-w-6xl px-4 pb-16 pt-8 sm:px-6 lg:px-10">
      {/* Cabeçalho */}
      <header className="mb-8 text-center sm:text-left">
        <p className="font-mono-tech text-[11px] uppercase tracking-[0.2em] text-[var(--gold)]">
          Salão virtual · 360°
        </p>
        <h1 className="mt-1 font-display text-3xl italic sm:text-4xl">
          Experimente antes de cortar
        </h1>
        <p className="mt-2 max-w-xl text-sm text-[var(--text-muted)] sm:mx-0 mx-auto">
          Carregue duas fotos, descubra o formato do seu rosto e gire o seu novo
          penteado em 3D antes de ir ao salão.
        </p>
      </header>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1fr)_420px]">
        {/* Coluna do espelho / viewport 3D */}
        <div className="space-y-5">
          <MirrorViewport />

          {!hasBothPhotos && (
            <div className="mx-auto max-w-[560px]">
              <DualPhotoUpload />
            </div>
          )}

          {hasBothPhotos && (
            <div className="mx-auto max-w-[560px]">
              <FaceShapeAnalysis />
            </div>
          )}
        </div>

        {/* Coluna de controlo */}
        <aside className="space-y-4">
          <nav className="flex gap-1 overflow-x-auto rounded-full border border-[var(--line)] p-1">
            {TABS.map((t) => (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`shrink-0 rounded-full px-3 py-2 text-xs font-medium transition-colors ${
                  tab === t.id
                    ? "bg-[var(--gold)] text-black"
                    : "text-[var(--text-muted)] hover:text-[var(--text)]"
                }`}
              >
                {t.label}
              </button>
            ))}
          </nav>

          {tab === "catalogo" && <StyleCatalog />}
          {tab === "cor" && <ColorTexturePanel />}
          {tab === "encaixe" && <FitAdjustPanel />}
          {tab === "comparar" && <BeforeAfterSlider />}
          {tab === "produtos" && <ProductRecommendations />}
          {tab === "partilhar" && <FriendsVotePanel />}
          {tab === "exportar" && <ExportCard />}
        </aside>
      </div>
    </main>
  );
}
